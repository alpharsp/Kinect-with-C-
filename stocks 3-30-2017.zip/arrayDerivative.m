function derivative=arrayDerivative(inputArray);
      derivative=zeros(max(size(inputArray)),1);
      for j=2:max(size(inputArray))-1
        delta=(inputArray(j-1)-inputArray(j+1))./2;
        derivative(j,1)=delta;
      end
end