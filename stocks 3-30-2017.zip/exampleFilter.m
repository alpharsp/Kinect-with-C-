u=@(n)1.0.*(n>=2);
y=@(n)abs(2.*n+1).*(u(n+1)-u(n-5));

n_x=1:10;
n_y=-2:20;

y_n=u(n_y);
x_n=y(n_x);

c=conv(x_n,y_n);
n_c= n_x(1)+n_y(1):n_x(end)+n_y(end);

figure()
%
subplot(4,1,1)
stem(n_c,c)
xlabel('n')
xlim([-3,15])
title('u(n)  *  |2n+1|(u(n+1)-u(n-5)) using conv')
%
cf=filter(x_n,1,y_n);
cf=[cf,zeros(1,length(n_c)-length(cf))];
subplot(4,1,2)
stem(n_c,cf)
xlabel('n')
xlim([-3,15])
title('u(n)  *  |2n+1|(u(n+1)-u(n-5)) using filter')