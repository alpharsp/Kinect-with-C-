function maxValsIndex= detectMaxRuper(inputArray,divisionSize)
    %Barrido con una ventana de 1/10 de los items totales, desde el inicio se determina cual es el de mayor valor
    %avanzamos de 1 en uno en la ventana y vemos si sigue siendo el mayor, si llegamos al punto donde esta fuera de la ventana y sigue siendo el mayor
    %grabamos el punto, luego iniciamos denuevo con 1 item despues del item mas bajo que tengamos actualmente en la ventana y seguimos
    %SIZE OF THE WINDOW: (1 20th of the data for the moment)
    %Division size is the fraction that the data will be divided into i.e if divisionSize=20 then the window will be 1/20th of the data
      totSamples=size(inputArray,1);
      barridoLength=ceil(totSamples/divisionSize);
      counter=0;
      firstTime=true;
      i=1;
    while i<=totSamples
        barridoMin=i;
        barridoMax=i+barridoLength-1;
        if barridoMax>totSamples
            barridoMax=totSamples;
        end
        %Data in the window
        itemsIndex=barridoMin:1:barridoMax;
        tempArray=inputArray(itemsIndex,:);
        tempMax=max(tempArray); %maxValue of the current window
        %If its the first time the historic amx index is going to be the max index of the current window
        maxIndex=max(find(tempArray==tempMax))+barridoMin-1; %index of the max number relative to the data, not the window
        if firstTime==true
          historicMaxIndex=maxIndex;
          if maxIndex>2
            i=maxIndex-1;
          end
          firstTime=false;
        else
            %check if the previous max item is still visible in the window
            if historicMaxIndex<barridoMin
              %not visible anymore, need the write the previous one
              counter=counter+1;
              maxValsIndex(counter)=historicMaxIndex;
              %now that it is recorded we need to start again from the current window, find the smallest value
              %and locate the first value of the window there
              tempMin=min(tempArray);
              minIndex=min(find(tempArray==tempMin))+barridoMin-1;
              i=minIndex;
              firstTime=true;
            else
              if tempMax>inputArray(historicMaxIndex)
                %there is a new max value, replace the previous one
                historicMaxIndex=maxIndex;
                i=maxIndex-1;
              end
            end
        end 
        i=i+1;
    end
    counter=counter+1;
    maxValsIndex(counter)=historicMaxIndex;
end