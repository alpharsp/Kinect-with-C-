function stock = stockClass(stockSymbol,stockData,stockWeekAVG,stockWeekDelta,stockWeekDP)
  stock.data=stockData;
  stock.symbol=stockSymbol;
  stock.weekAVG=stockWeekAVG;
  stock.weekDelta=stockWeekDelta;
  stock.weekDeltaPercent=stockWeekDP;
end
