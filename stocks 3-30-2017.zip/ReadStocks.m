function StockData = ReadStocks(Address)
%%THE COLUMNS IN THE DATASET ARE: [Date,Open,High,Low,Close,Volume,AdjClose]
%%THE VARIABLES OF EACH STOCK OBJECTS ARE:
%%stock.data
%%stock.symbol
%%stock.weekAVG
%%stock.weekDelta
%%stock.weekDeltaPercent
%%stock.weekDomain
%%------------------------------------------------------------------------------
%Load Needed Packages
  pkg load io %For excel
  pkg load financial  %For Julian Calendar Values
%Read Data File and save Dta in stock objects
  [status,sheets]=xlsfinfo(Address);
  totSheets=size(sheets(:,1),1);
  sheetNames=sheets(1:1:totSheets,1);
%For each stock
  for i=1:totSheets
    symbol=cell2mat(sheetNames(i));
    tempStockData=xlsread(Address,symbol);
    tempStockData=flipud(tempStockData);
    [totRows,totCols]=size(tempStockData);
    %Weekly Average Data
      weekAvgData = weeklyAverage(tempStockData);
    %Derivative based on the weekly analysis (this is in dollars per week)
      weekDelta=[weekAvgData(:,1),weekAvgData(:,2),arrayDerivative(weekAvgData(:,3))];
    %Derivative in terms of percentual quantities (% per week)
      weekDPercent=[weekAvgData(:,1),weekAvgData(:,2),weekDelta(:,3).*100./weekAvgData(:,3)];
      %Create stock object
      StockData(i)=stockClass(symbol,tempStockData,weekAvgData,weekDelta,weekDPercent,weekDomain);
  end

 