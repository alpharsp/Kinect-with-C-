function filterStock(dates,data)
%Caclulate N points, the N points need to be at least the number of original points
totItems=size(data,1);
N=2^(ceil(log2(totItems)));
pkg load signal
%Specs From the problem
wp=(1/5)*pi; %End of pass band
ws=((1/5)+1/(5*10))*pi;%Begining of stop band
Rp=0.25; %Pass band allowed ripple (dB)
As=50; %Attenuation (dB)
%Due to As=50dB we selected the hamming window to operate
wDelta=ws-wp; %Transition band
M=round(6.6*pi/wDelta);%Formula to calculate length of window required to 
%satisfy the wDelta (Half the size of it's mainlobe)
alpha=(M-1)/2; %Linear Phase
wc=(ws+wp)/2; %Cut Freq, half way between ws and wp
Window=hamming(M)'; %Creates a hamming window of length M in row form (transpose)
n=0:(M-1); %n values for each point of the window
%Ideal filter
h=(wc/pi)*sinc((wc/pi)*(n-alpha)); %The filter in time domain (not windowed yet)
%Final Filter
h=h.*Window; %Windowed Filter
%h is b the coeficient of numerator a is the coeficients of denominator
a=[1];%FRI no feedback
%Getting the freq response of the filter
H=freqz(h,a,N); %freq response of the filter
w=linspace(0,(N-1)/N,N); %domain of freq response from0 to 1
HM=abs(H); %Magnitudes of the freq response
HA=unwrap(angle(H)); %phase of freq response
HdbM=20*log10(HM);
%------------------------------------------------------------------------------
%Plot Raw Data
figure;
stem(data);
%Plot original filter
Filter=HM;
%figure;
%stem(HM);
%FILTER BY A CONCATENATION IN THE TIME DOMAIN
tFilter=ifft(Filter); %Filter in Time Domain
fData=conv(data,tFilter); %Filtering the data
fData=fData(1:1:totItems,:); %since it is L(Data)+L(filter) long we only need the first N items with the size of the data
%COMPENSATE THE ENERGY LOSS
fData=fData.*(mean(data)/mean(fData));
hold;
stem(fData);
hold;

end