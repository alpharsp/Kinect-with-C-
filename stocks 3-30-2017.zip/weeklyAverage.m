function matrix = weeklyAverage(StockData)
      %Weekly Analysis [weeknumber,year,avergae price] only 1 average value per week
      tempWeekAvgData=[weeknum(StockData(:,1)),year(StockData(:,1))+1900,(StockData(:,3)+StockData(:,4))./2];
      totRows=size(tempWeekAvgData,1);
      totCols=size(tempWeekAvgData,2);
      uniques=size(unique((tempWeekAvgData(:,2).*100)+tempWeekAvgData(:,1)),1);
      weekAvgData=zeros(uniques,totCols);
      counter=1;
      index=1;
      while counter<=totRows-1
        currentWeek=tempWeekAvgData(counter,1);
        currentYear=tempWeekAvgData(counter,2);
        dayPrice=tempWeekAvgData(counter,3);
        tempSum=dayPrice;
        itemsCount=1;
        counter=counter+1;
        while counter<=totRows-1 && currentWeek==tempWeekAvgData(counter,1)
            dayPrice=tempWeekAvgData(counter,3);
            tempSum=tempSum+dayPrice;
            itemsCount=itemsCount+1;
            counter=counter+1;
        end
        weekAvgData(index,:)=[currentWeek,currentYear,tempSum/itemsCount];
        index=index+1;
      end
      matrix=weekAvgData;
end