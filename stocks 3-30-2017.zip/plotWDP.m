function plotWDP(stockObject,nMarkers)
  %PLOTS THE WEEKLY DERIVATIVES OF THE STOCK IN A RATE WHICH IS PERCENTUAL TO 
  %THE PRICE OF THE STOCK AT THE GIVEN MOMENT
  %stockObject IS AN OBJECT OF CLASS stockClass
  %nMarkers IS THE NUMBER OFDATES YOU WANT TO SHOW IN THE DOMAIN AXIS
  inputArray=stockObject.weekDeltaPercent(:,3);
  weeks=stockObject.weekDeltaPercent(:,1);
  years=stockObject.weekDeltaPercent(:,2);
  totSamples=size(inputArray,1);
  relPosX=(1/(totSamples-1)).*(0:1:totSamples-1); %numbers between 0 and 1
  plot(inputArray)
  minChange=min(inputArray);
  maxChange=max(inputArray);
  ylim([minChange,maxChange]);
  xlim([0,size(stockObject.weekDeltaPercent,1)])
  totItems=nMarkers;
  separation=ceil(size(weeks,1)./totItems);
  items=1:separation:totSamples;
  totItems=size(items,2); %It could have change due to the ceil
  %Add labels
    set(gca,'Xtick',[]); %Remove currentlabels
    for i=1:totItems
      index=items(i);
      weekStr=mat2str(weeks(index,1));
      yearStr= mat2str(years(index,1));
      currentText=[weekStr, 'w/' ,yearStr];
      text(relPosX(index),-0.025, currentText ,'Units','normalized','HorizontalAlignment','left','Rotation',-90);
    end
    title(stockObject.symbol);
end