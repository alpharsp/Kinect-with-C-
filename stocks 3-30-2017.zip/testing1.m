%VARIABLES
  %Term lengths in days
    shortTerm=90;
    midTerm=180;
    longTerm=365*3;
  %Analyze
    sAnalyze=[longTerm,midTerm,shortTerm];
    stockIndexMin=7;
    stockIndexMax=7;
  %Avoid zeroDivision
    tol=1*10^(-5);
%CONSTANTS
    maxPoints=10;
    minPoints=10;
%READ DATA
    Address='EXTRACT1.xlsx';
    %StockData=ReadStocks(Address);
%STOCK INDEX
  for i=stockIndexMin:stockIndexMax
      %Number of analysis
      totAnalysis=size(sAnalyze,2);
      for aCounter=1:totAnalysis
          DataSet=((StockData(i).data(:,3)+StockData(i).data(:,4))./2); %average of each day
          N=size(DataSet,1);
          DataSet=DataSet(N-sAnalyze(1,aCounter)+1:1:N);
          fractionalSizeOfWindow=1;
          maxP=0;
          minP=0;
          while and(fractionalSizeOfWindow<=N,or(maxP<=maxPoints,minP<=minPoints))
              maxPointsIndex=unique(detectMaxRuper(DataSet,fractionalSizeOfWindow));
              minPointsIndex=unique(detectMinRuper(DataSet,fractionalSizeOfWindow));
              maxP=size(maxPointsIndex,2);
              minP=size(minPointsIndex,2);
              fractionalSizeOfWindow=fractionalSizeOfWindow+1;
          end
          n=size(DataSet,1);
          %Create the line as an average on gradient and bias
            xAxis=1:1:n; %xAxis for the line
            totMaxP=size(maxPointsIndex,2);
            mLine=0;
            mMax=0;
            bOfMMax=0;
            b=0;
            minErrorM=0;
            minErrorB=0;
            linesCounter=0;
            lastError=0;
            %All possible combination of lines, calculate the erro for each one (line to point diff)
            %keep the one that has the smaller error
            for j=1:totMaxP-1
              for k=j+1:totMaxP
                point1x=maxPointsIndex(j);
                point1y=DataSet(maxPointsIndex(j));
                point2x=maxPointsIndex(k);
                point2y=DataSet(maxPointsIndex(k));
                tempMLine=(point2y-point1y)/(point2x-point1x+tol);
                tempB=point1y-tempMLine*point1x;
                %measure the error for current line against every point
                error=0;
                for c1=1:totMaxP
                  tempPointx=maxPointsIndex(c1);
                  tempPointy=DataSet(maxPointsIndex(c1));
                  error=error+abs((tempMLine*tempPointx)+tempB-tempPointy);
                end
                  linesCounter=linesCounter+1;
                  if linesCounter==1
                      smallestError=error;
                      minErrorB=tempB;
                      minErrorM=tempMLine;
                  else
                      if error<smallestError
                          smallestError=error;
                          minErrorB=tempB;
                          minErrorM=tempMLine;
                      end
                  end
              end
            end
            %the one lines with the smallest error will be the good one
              mLine=minErrorM;
              b=minErrorB;
              yAxis=(mLine.*xAxis)+b;
          %DISPLAY
              figure;
              stem(DataSet);
              hold;
              scatter(maxPointsIndex,DataSet(maxPointsIndex,:),'fill');
              scatter(minPointsIndex,DataSet(minPointsIndex,:),'fill');
              scatter(maxPointsIndex,DataSet(maxPointsIndex,:),'fill');
              plot(xAxis,yAxis);
              title([StockData(i).symbol,'   ',mat2str(mLine),'% per day']);hold;
       end
   end